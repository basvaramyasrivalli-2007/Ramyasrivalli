// Digital Library System - Beginner Backend

// 1. Import modules
const express = require("express");
const mongoose = require("mongoose");

// 2. Create app
const app = express();

// 3. Middleware
app.use(express.json());

// 4. Connect MongoDB
mongoose.connect("mongodb://[Log in to view URL]:27017/libraryDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));


// 5. Create Schema
const bookSchema = new mongoose.Schema({
    title: String,
    author: String,
    year: Number,
    available: {
        type: Boolean,
        default: true
    }
});

// 6. Create Model
const Book = mongoose.model("Book", bookSchema);


// 7. Routes

// ➤ Add Book
app.post("/addBook", async (req, res) => {
    try {
        const book = new Book(req.body);
        await book.save();
        res.send("Book Added Successfully");
    } catch (err) {
        res.status(500).send(err);
    }
});


// ➤ Get All Books
app.get("/books", async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (err) {
        res.status(500).send(err);
    }
});


// ➤ Issue Book
app.put("/issueBook/:id", async (req, res) => {
    try {
        await Book.findByIdAndUpdate(req.params.id, { available: false });
        res.send("Book Issued");
    } catch (err) {
        res.status(500).send(err);
    }
});


// ➤ Return Book
app.put("/returnBook/:id", async (req, res) => {
    try {
        await Book.findByIdAndUpdate(req.params.id, { available: true });
        res.send("Book Returned");
    } catch (err) {
        res.status(500).send(err);
    }
});


// ➤ Delete Book
app.delete("/deleteBook/:id", async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.send("Book Deleted");
    } catch (err) {
        res.status(500).send(err);
    }
});


// 8. Start Server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});